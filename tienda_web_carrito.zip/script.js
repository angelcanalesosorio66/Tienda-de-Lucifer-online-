let carrito = [];
let total = 0;

function agregarAlCarrito(servicio, precio) {
  carrito.push({ servicio, precio });
  total += precio;
  document.getElementById('contador').innerText = carrito.length;
}

function mostrarCarrito() {
  const lista = document.getElementById('lista-carrito');
  lista.innerHTML = '';
  carrito.forEach((item, index) => {
    const li = document.createElement('li');
    li.textContent = item.servicio + ' - $' + item.precio;
    lista.appendChild(li);
  });
  document.getElementById('total').innerText = total;
  document.getElementById('carrito').style.display = 'block';
}

function cerrarCarrito() {
  document.getElementById('carrito').style.display = 'none';
}

function pagar() {
  alert('Gracias por tu compra. Pago simulado.');
  carrito = [];
  total = 0;
  document.getElementById('contador').innerText = 0;
  cerrarCarrito();
}
